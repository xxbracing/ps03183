<script type="text/javascript" src="js/slider.js"></script>

<div id="slider">
<div id="img">
<div class="neoslideshow">

 <img src="images/2014101318304417.jpg" width="970" height="415" />

  <img src="images/banner.png"  width="970" height="415"  />

  <img src="images/banner_khodienthoai.jpg"  width="970" height="415"  />

  <img src="images/banner3__25143-1024x455.jpg"  width="970" height="415"  />

  <img src="images/New-iPhone-4S-Banner.jpg"  width="970" height="415" />

</div>

</div>
</div>