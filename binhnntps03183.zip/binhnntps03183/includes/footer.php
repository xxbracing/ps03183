<div id="marginfooter">
<div class="muc">

<span>Liên hệ</span>





<p>Địa chỉ:27 Núi Thành - Hải Châu - Đà Nẵng</p>
<p >Điện thoại:01205307920</ơ>
<p >Fax:</p>
<p >Email:rynphan6@gmail.com</p>

</div>


<div class="muc">
<span>Menu</span><div id="menufooter">

<ul>
<li><a href="?mod=home">Trang chủ</a></li>
<li><a href="?mod=gioithieu">Giới thiệu</a></li>
<li><a href="?mod=products">Sản Phẩm</a></li>
<li><a href="?mod=lienhe">Liên hệ</a></li>
<li><a href="?mod=mali">Bản đồ</a></li>
</ul>

</div></div>
<div class="muc">
<span>Danh mục</span><div id="danhmucfooter">
<ul >
	<li><a href="?mod=products&type=1">Điện thoại di động</a>
	
	  </li>
		<li><a href="?mod=products&type=2">Máy tính bảng</a>
	
	  </li>
	  <li><a href="?mod=products&type=3">Máy tính xách tay</a>
	
	  </li>
	  <li><a href="?mod=products&type=5">Phụ kiện điện thoại</a>
	
	  </li>
	</ul>



</div></div>
<div class="muc">
<span>Tìm kiếm</span>
<div id="search">

<label>Search</label>
<input type="text" name="txtSearchText"  id="text" value="" />
<input type="submit" name="btnSearch" value="Tìm Kiếm" id="button" />

</div></div>
<div class="clear"></div>
</div>

<div class="thietke">
		Thiết kế bởi: <span> Phan Châu Thành </span>
		</div>