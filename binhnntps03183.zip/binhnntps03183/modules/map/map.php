<h3>Bản Đồ</h3>

	 <iframe width="700" height="400"  frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=vi&amp;geocode=&amp;q=27+N%C3%BAi+Th%C3%A0nh,+H%E1%BA%A3i+Ch%C3%A2u,+%C4%90%C3%A0+N%E1%BA%B5ng&amp;aq=0&amp;oq=27&amp;sll=16.052577,108.213186&amp;sspn=0.006279,0.010504&amp;gl=vn&amp;ie=UTF8&amp;hq=&amp;hnear=27+N%C3%BAi+Th%C3%A0nh,+H%E1%BA%A3i+Ch%C3%A2u,+%C4%90%C3%A0+N%E1%BA%B5ng&amp;ll=16.052577,108.213186&amp;spn=0.006279,0.010504&amp;t=m&amp;z=14&amp;output=embed"></iframe>
					    <br />
				      <small>Xem <a href="https://maps.google.com/maps?f=q&amp;source=embed&amp;hl=vi&amp;geocode=&amp;q=27+N%C3%BAi+Th%C3%A0nh,+H%E1%BA%A3i+Ch%C3%A2u,+%C4%90%C3%A0+N%E1%BA%B5ng&amp;aq=0&amp;oq=27&amp;sll=16.052577,108.213186&amp;sspn=0.006279,0.010504&amp;gl=vn&amp;ie=UTF8&amp;hq=&amp;hnear=27+N%C3%BAi+Th%C3%A0nh,+H%E1%BA%A3i+Ch%C3%A2u,+%C4%90%C3%A0+N%E1%BA%B5ng&amp;ll=16.052577,108.213186&amp;spn=0.006279,0.010504&amp;t=m&amp;z=14" style="color:#0000FF;text-align:left">TP Đà Nẵng - Việt Nam</a> ở bản đồ lớn hơn</small><br />
				
