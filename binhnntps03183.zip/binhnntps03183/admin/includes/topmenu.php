<?php ?>
<div id="dangnhap">
<div id="top">

	<div id="bg-menu">

<ul>
	<li><a href="#">Tài khoản của tôi</a></li>
-
	<li><a href="#">Quản lí đơn hàng</a></li>
-
	<li><a href="#">Danh sách ưa thích</a></li>-
	<li><a href="#">Giỏ hàng</a></li>-
	<li><a href="#">Đăng nhập</a></li>-
	<li><a href="#">Đăng kí</a></li>
	</ul>
	
	</div>
</div>
</div><div class="clear"></div>