

<div id="slider">
<div id="img">
<img src="images/2014101318304417.jpg" width="970" height="415" alt="" /></div>
</div>