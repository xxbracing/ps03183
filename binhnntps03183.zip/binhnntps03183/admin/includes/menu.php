
<div id="nav-menu">

	<ul >
	<li><a href="#">Trang chủ</a>
	
	  </li>
		<li><a href="#">Giới thiệu</a>
	
	  </li>
	  <li><a href="#">Sản phẩm</a>
	
	  </li>
	  <li><a href="#">Tin tức</a>
	
	  </li>
	  <li><a href="#">Liên hệ</a>
	
	  </li>
	  <li><a href="#">Bản đồ</a>
	
	  </li>		
	</ul>
	</div>
	

